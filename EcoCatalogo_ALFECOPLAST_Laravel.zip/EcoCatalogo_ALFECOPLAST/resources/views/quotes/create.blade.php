@extends('layouts.app') @section('title','Solicitar cotización')
@section('content')<div class="form-card wide"><h1>Solicitar cotización</h1><p>Completa la información. Los campos con asterisco son obligatorios.</p><form method="POST" action="{{ route('quotes.store') }}" enctype="multipart/form-data">@csrf
<label>Producto *<select name="product_id" required>@foreach($products as $p)<option value="{{ $p->id }}" @selected(old('product_id',$product?->id)==$p->id)>{{ $p->name }}</option>@endforeach</select></label>
<label>Cantidad requerida *<input type="number" min="1" max="1000000" name="quantity" value="{{ old('quantity',100) }}" required></label>
<div class="two-fields"><label>Empresa *<input name="company_name" value="{{ old('company_name',auth()->user()->company) }}" required></label><label>Nombre de contacto *<input name="contact_name" value="{{ old('contact_name',auth()->user()->name) }}" required></label></div>
<div class="two-fields"><label>Correo *<input type="email" name="contact_email" value="{{ old('contact_email',auth()->user()->email) }}" required></label><label>Teléfono<input name="contact_phone" value="{{ old('contact_phone',auth()->user()->phone) }}"></label></div>
<label>¿Deseas personalizar el producto? *<select name="customization_requested"><option value="0" @selected(old('customization_requested')==='0')>No</option><option value="1" @selected(old('customization_requested')==='1')>Sí</option></select></label>
<label>Colores de referencia<input name="colors" value="{{ old('colors') }}" placeholder="Ej. verde y blanco"></label>
<label>Logotipo (opcional, máximo 2 MB)<input type="file" name="logo" accept="image/*"></label>
<label>Detalles de personalización<textarea name="customization_notes" rows="3">{{ old('customization_notes') }}</textarea></label>
<label>Observaciones adicionales<textarea name="notes" rows="3">{{ old('notes') }}</textarea></label>
<button class="btn full" data-loading>Enviar solicitud</button></form></div>@endsection
