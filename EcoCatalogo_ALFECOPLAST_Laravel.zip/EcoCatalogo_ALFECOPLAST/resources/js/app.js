import './bootstrap';
document.addEventListener('submit', (event) => {
  const button = event.target.querySelector('[data-loading]');
  if (button) {
    button.disabled = true;
    button.dataset.originalText = button.textContent;
    button.textContent = 'Procesando...';
    button.classList.add('is-loading');
  }
});
