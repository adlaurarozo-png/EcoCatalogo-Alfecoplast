<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CatalogController;
use App\Http\Controllers\QuoteController;
use App\Http\Controllers\AdminController;

Route::get('/', [CatalogController::class, 'index'])->name('home');
Route::get('/catalogo', [CatalogController::class, 'index'])->name('catalog.index');
Route::get('/productos/{product}', [CatalogController::class, 'show'])->name('catalog.show');

Route::middleware('guest')->group(function () {
    Route::get('/registro', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/registro', [AuthController::class, 'register'])->name('register.store');
    Route::get('/ingresar', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/ingresar', [AuthController::class, 'login'])->name('login.store');
});
Route::post('/salir', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::middleware(['auth', 'role:cliente'])->group(function () {
    Route::get('/solicitudes/crear/{product?}', [QuoteController::class, 'create'])->name('quotes.create');
    Route::post('/solicitudes', [QuoteController::class, 'store'])->name('quotes.store');
    Route::get('/mis-solicitudes', [QuoteController::class, 'index'])->name('quotes.index');
    Route::get('/mis-solicitudes/{quote}', [QuoteController::class, 'show'])->name('quotes.show');
});
Route::prefix('admin')->name('admin.')->middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/', [AdminController::class, 'index'])->name('dashboard');
    Route::get('/productos', [AdminController::class, 'products'])->name('products');
    Route::post('/productos', [AdminController::class, 'storeProduct'])->name('products.store');
    Route::get('/solicitudes', [AdminController::class, 'quotes'])->name('quotes');
    Route::patch('/solicitudes/{quote}', [AdminController::class, 'updateQuote'])->name('quotes.update');
});
