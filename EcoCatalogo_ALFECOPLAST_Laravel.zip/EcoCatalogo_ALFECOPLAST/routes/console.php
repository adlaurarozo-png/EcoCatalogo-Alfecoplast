<?php
// Console routes.
