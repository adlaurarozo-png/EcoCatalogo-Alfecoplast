<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
class Quote extends Model {
    protected $fillable = ['user_id','code','status','company_name','contact_name','contact_email','contact_phone','notes','customization_requested','logo_path','colors','admin_response'];
    protected function casts(): array { return ['customization_requested'=>'boolean']; }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function items(): HasMany { return $this->hasMany(QuoteItem::class); }
}
