<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Product extends Model {
    protected $fillable = ['category_id','name','slug','description','image_url','reference_price','is_active'];
    protected function casts(): array { return ['reference_price'=>'decimal:2','is_active'=>'boolean']; }
    public function category(): BelongsTo { return $this->belongsTo(Category::class); }
}
