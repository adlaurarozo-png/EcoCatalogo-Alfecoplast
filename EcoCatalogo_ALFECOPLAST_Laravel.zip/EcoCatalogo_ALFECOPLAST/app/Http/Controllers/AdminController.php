<?php
namespace App\Http\Controllers;
use App\Models\Product;
use App\Models\Category;
use App\Models\Quote;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
class AdminController extends Controller {
    public function index() {
        return view('admin.dashboard', [
            'products'=>Product::count(),'quotes'=>Quote::count(),
            'pending'=>Quote::whereIn('status',['recibida','en_revision'])->count(),
            'recent'=>Quote::with('user')->latest()->take(6)->get()
        ]);
    }
    public function products() {
        return view('admin.products', ['products'=>Product::with('category')->latest()->paginate(12),'categories'=>Category::where('is_active',true)->get()]);
    }
    public function storeProduct(Request $request) {
        $data = $request->validate([
            'category_id'=>'required|exists:categories,id','name'=>'required|string|max:160',
            'description'=>'required|string|max:2000','reference_price'=>'nullable|numeric|min:0',
            'image_url'=>'nullable|url|max:500'
        ]);
        $data['slug'] = Str::slug($data['name']).'-'.Str::lower(Str::random(5));
        $data['is_active'] = true;
        Product::create($data);
        return back()->with('success','Producto creado correctamente.');
    }
    public function quotes() {
        return view('admin.quotes',['quotes'=>Quote::with(['user','items.product'])->latest()->paginate(15)]);
    }
    public function updateQuote(Request $request, Quote $quote) {
        $data = $request->validate(['status'=>'required|in:recibida,en_revision,cotizacion_enviada,aprobada,finalizada,requiere_informacion','admin_response'=>'nullable|string|max:2000']);
        $quote->update($data);
        return back()->with('success','Solicitud actualizada.');
    }
}
