<?php
namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;
class AuthController extends Controller {
    public function showLogin() { return view('auth.login'); }
    public function showRegister() { return view('auth.register'); }
    public function register(Request $request) {
        $data = $request->validate([
            'name'=>'required|string|max:120','company'=>'required|string|max:160',
            'email'=>'required|email|max:160|unique:users,email','phone'=>'nullable|string|max:40',
            'password'=>['required','confirmed',Password::min(8)]
        ]);
        $data['password'] = Hash::make($data['password']);
        $data['role'] = 'cliente';
        $user = User::create($data);
        Auth::login($user);
        $request->session()->regenerate();
        return redirect()->route('catalog.index')->with('success','Tu cuenta fue creada correctamente.');
    }
    public function login(Request $request) {
        $credentials = $request->validate(['email'=>'required|email','password'=>'required|string']);
        if (!Auth::attempt($credentials, $request->boolean('remember'))) {
            return back()->withErrors(['email'=>'Los datos de acceso no son correctos.'])->onlyInput('email');
        }
        $request->session()->regenerate();
        return Auth::user()->role === 'admin' ? redirect()->route('admin.dashboard') : redirect()->intended(route('catalog.index'));
    }
    public function logout(Request $request) {
        Auth::logout(); $request->session()->invalidate(); $request->session()->regenerateToken();
        return redirect()->route('home')->with('success','Sesión cerrada correctamente.');
    }
}
