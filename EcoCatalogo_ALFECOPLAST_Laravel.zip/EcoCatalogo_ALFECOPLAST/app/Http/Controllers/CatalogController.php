<?php
namespace App\Http\Controllers;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
class CatalogController extends Controller {
    public function index(Request $request) {
        $query = Product::with('category')->where('is_active',true);
        if ($request->filled('q')) $query->where('name','like','%'.$request->string('q').'%');
        if ($request->filled('category')) $query->where('category_id',$request->integer('category'));
        return view('catalog.index', ['products'=>$query->latest()->paginate(9)->withQueryString(),'categories'=>Category::where('is_active',true)->orderBy('name')->get()]);
    }
    public function show(Product $product) {
        abort_unless($product->is_active,404);
        return view('catalog.show', compact('product'));
    }
}
