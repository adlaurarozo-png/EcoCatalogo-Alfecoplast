<?php
namespace App\Http\Controllers;
use App\Models\Product;
use App\Models\Quote;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
class QuoteController extends Controller {
    public function index(Request $request) {
        $quotes = $request->user()->quotes()->with('items.product')->latest()->paginate(10);
        return view('quotes.index', compact('quotes'));
    }
    public function create(?Product $product = null) {
        $products = Product::where('is_active',true)->orderBy('name')->get();
        return view('quotes.create', compact('products','product'));
    }
    public function store(Request $request) {
        $data = $request->validate([
            'product_id'=>'required|exists:products,id','quantity'=>'required|integer|min:1|max:1000000',
            'company_name'=>'required|string|max:160','contact_name'=>'required|string|max:120',
            'contact_email'=>'required|email|max:160','contact_phone'=>'nullable|string|max:40',
            'customization_requested'=>'required|in:0,1','colors'=>'nullable|string|max:180',
            'customization_notes'=>'nullable|string|max:1500','notes'=>'nullable|string|max:1500',
            'logo'=>'nullable|image|max:2048'
        ]);
        $product = Product::where('is_active',true)->findOrFail($data['product_id']);
        $logoPath = $request->file('logo')?->store('logos','public');
        $quote = DB::transaction(function () use ($request,$data,$product,$logoPath) {
            $quote = Quote::create([
                'user_id'=>$request->user()->id,'code'=>'ECO-'.strtoupper(Str::random(7)),
                'status'=>'recibida','company_name'=>$data['company_name'],'contact_name'=>$data['contact_name'],
                'contact_email'=>$data['contact_email'],'contact_phone'=>$data['contact_phone'] ?? null,
                'notes'=>$data['notes'] ?? null,'customization_requested'=>(bool)$data['customization_requested'],
                'logo_path'=>$logoPath,'colors'=>$data['colors'] ?? null
            ]);
            $quote->items()->create([
                'product_id'=>$product->id,'quantity'=>$data['quantity'],
                'unit_price'=>$product->reference_price,
                'customization_notes'=>$data['customization_notes'] ?? null
            ]);
            return $quote;
        });
        return redirect()->route('quotes.show',$quote)->with('success','Tu solicitud fue recibida correctamente.');
    }
    public function show(Request $request, Quote $quote) {
        abort_unless($quote->user_id === $request->user()->id,403);
        $quote->load('items.product');
        return view('quotes.show', compact('quote'));
    }
}
