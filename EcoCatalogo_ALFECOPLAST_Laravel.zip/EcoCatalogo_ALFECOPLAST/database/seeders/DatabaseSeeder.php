<?php
namespace Database\Seeders;
use App\Models\User; use App\Models\Category; use App\Models\Product;
use Illuminate\Database\Seeder; use Illuminate\Support\Facades\Hash;
class DatabaseSeeder extends Seeder {
 public function run(): void {
  User::updateOrCreate(['email'=>'admin@ecocatalogo.test'],['name'=>'Administrador EcoCatálogo','company'=>'ALFECOPLAST','password'=>Hash::make('Admin12345!'),'role'=>'admin']);
  User::updateOrCreate(['email'=>'cliente@ecocatalogo.test'],['name'=>'Cliente de prueba','company'=>'Empresa Demostración','password'=>Hash::make('Cliente12345!'),'role'=>'cliente']);
  $items = [
   ['name'=>'Vasos ecológicos','description'=>'Vasos para consumo institucional y eventos. Solicita cotización según material y capacidad.'],
   ['name'=>'Platos y bandejas','description'=>'Alternativas para servicio de alimentos, eventos y establecimientos comerciales.'],
   ['name'=>'Cubiertos desechables','description'=>'Cubiertos para servicios de alimentación y consumo fuera del hogar.'],
   ['name'=>'Bolsas y empaques','description'=>'Empaques y bolsas para presentación y entrega de productos.'],
   ['name'=>'Productos personalizados','description'=>'Productos que pueden llevar identidad gráfica, colores y especificaciones de tu empresa.']
  ];
  foreach ($items as $i=>$item) {
   $category=Category::firstOrCreate(['name'=>$item['name']],['description'=>'Categoría de productos ALFECOPLAST','is_active'=>true]);
   Product::firstOrCreate(['slug'=>\Illuminate\Support\Str::slug($item['name']).'-demo'],[
    'category_id'=>$category->id,'name'=>$item['name'].' - Referencia demo','slug'=>\Illuminate\Support\Str::slug($item['name']).'-demo',
    'description'=>$item['description'],'reference_price'=>null,'is_active'=>true
   ]);
  }
 }
}
