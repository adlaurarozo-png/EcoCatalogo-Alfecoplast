<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void { Schema::create('users', function (Blueprint $table) {
  $table->id(); $table->string('name'); $table->string('company')->nullable(); $table->string('email')->unique();
  $table->string('phone')->nullable(); $table->timestamp('email_verified_at')->nullable(); $table->string('password');
  $table->enum('role',['admin','cliente'])->default('cliente'); $table->rememberToken(); $table->timestamps();
 }); }
 public function down(): void { Schema::dropIfExists('users'); }
};
