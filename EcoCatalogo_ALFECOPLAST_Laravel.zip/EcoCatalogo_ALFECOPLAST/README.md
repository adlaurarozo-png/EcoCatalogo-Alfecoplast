# EcoCatálogo ALFECOPLAST

Aplicación académica desarrollada con Laravel 12 para consultar productos desechables, ecológicos y personalizados y registrar solicitudes de cotización.

## Alcance implementado
- Roles: administrador y cliente.
- Registro e inicio/cierre de sesión.
- Catálogo con búsqueda y filtro por categoría.
- Solicitud de cotización con cantidad, datos de contacto y personalización.
- Carga opcional de logotipo.
- Persistencia en base de datos y código de solicitud.
- Consulta de solicitudes propias por parte del cliente.
- Panel de administración, alta de productos y actualización del estado de solicitudes.
- Interfaz adaptable y mensajes de validación, éxito y procesamiento.

## Requisitos locales
- PHP 8.2 o superior y extensiones requeridas por Laravel (OpenSSL, PDO, Mbstring, Tokenizer, XML, Ctype, JSON, BCMath, Fileinfo).
- Composer 2.
- Node.js y npm.
- SQLite (incluido como opción inicial) o MySQL/MariaDB.

**Este paquete no incluye Docker ni Lando**, de acuerdo con el alcance solicitado por la estudiante. El taller original sí asigna 30% al entorno Ubuntu/Docker/Lando; omitir esa parte puede afectar esa calificación.

## Instalación en Windows (PowerShell) o macOS/Linux
1. Descomprime el ZIP y abre una terminal en la carpeta `EcoCatalogo_ALFECOPLAST`.
2. Instala dependencias PHP:
   ```bash
   composer install
   ```
3. Crea el archivo de entorno:
   ```bash
   cp .env.example .env
   ```
   En Windows PowerShell:
   ```powershell
   Copy-Item .env.example .env
   ```
4. Genera la llave:
   ```bash
   php artisan key:generate
   ```
5. Crea el archivo SQLite:
   ```bash
   # macOS/Linux
   touch database/database.sqlite
   # Windows PowerShell
   New-Item database/database.sqlite -ItemType File
   ```
6. Instala dependencias frontend y compila:
   ```bash
   npm install
   npm run build
   ```
7. Ejecuta migraciones y datos de demostración:
   ```bash
   php artisan migrate --seed
   ```
8. Crea el enlace de almacenamiento para archivos:
   ```bash
   php artisan storage:link
   ```
9. Inicia el servidor:
   ```bash
   php artisan serve
   ```
10. Abre http://127.0.0.1:8000

## Base de datos MySQL (opcional)
En `.env`, configura:
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=ecocatalogo
DB_USERNAME=root
DB_PASSWORD=tu_clave
```
Crea previamente la base de datos `ecocatalogo` en MySQL y ejecuta `php artisan migrate --seed`.

## Usuarios de demostración
Después de ejecutar `php artisan migrate --seed`:
- Administrador: `admin@ecocatalogo.test` / `Admin12345!`
- Cliente: `cliente@ecocatalogo.test` / `Cliente12345!`

Cambia estas contraseñas antes de publicar el sistema. No utilices las credenciales de demostración en producción.

## Pruebas y comandos útiles
```bash
php artisan route:list
php artisan migrate:status
php artisan test
npm run dev
```

## Notas importantes
- Los productos sembrados son referencias de demostración; reemplázalos por el inventario real autorizado de ALFECOPLAST.
- El precio es referencial y opcional; la aplicación registra solicitudes, no procesa pagos ni confirma inventario.
- La autenticación es propia y sencilla para el ejercicio académico; antes de producción se recomienda ampliar seguridad, recuperación de contraseña, verificación de correo, políticas y pruebas.
- El archivo `.env` no se incluye. Mantén tus credenciales locales fuera del repositorio.
- Este ZIP contiene el código fuente y manifiestos de dependencias; no contiene `vendor/` ni `node_modules/`. Deben instalarse en el equipo donde se ejecutará.
- No se incluye `.git/` porque el ZIP es una copia generada en este entorno y no el repositorio GitHub personal de la estudiante. Para crear tu historial y conectar tu propio remoto: `git init`, `git add .`, `git commit -m "Estructura inicial EcoCatalogo"` y `git remote add origin URL_DE_TU_REPOSITORIO`.
